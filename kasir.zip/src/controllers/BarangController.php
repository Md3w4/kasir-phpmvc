<?php

class BarangController extends BaseController 
{
    public function index()
    {
        $data = [
            'title' => 'Data Barang',
            'label1' => 'General',
            'label2' => 'Barang',
            'label3' => ''
        ];
        $this->view('partials/header', $data);
        $this->view('barang/index');
        $this->view('partials/footer');
    }

    public function edit($id1 = '', $id2 = '')
    {
        echo 'edit cuy tes munculin id 1 =' . $id1 . 'dan id 2 =' . $id2;
    }
}
