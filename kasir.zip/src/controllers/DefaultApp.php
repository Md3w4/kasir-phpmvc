<?php

class DefaultApp extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Home',
            'label1' => '',
            'label2' => '',
            'label3' => '',
        ];
        $this->view('partials/header', $data);
        $this->view('index', $data);
        $this->view('partials/footer');
    }
}
