<div class="container mx-auto p-4">
    <div class="flex w-full overflow-x-auto">
        <table class="table-hover table">
            <thead>
                <tr>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Kadaluarsa</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>FRN-CHR-0156</th>
                    <td>Kursi Gaming</td>
                    <td>Rp. 500,000</td>
                    <td>300</td>
                    <td>-</td>
                    <td>kursigaming.jpg</td>
                    <td><button class="btn btn-solid-warning">Ubah</button>
                        <button class="btn btn-solid-error">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <th>FRN-CHR-0156</th>
                    <td>Kursi Gaming</td>
                    <td>Rp. 500,000</td>
                    <td>300</td>
                    <td>-</td>
                    <td>kursigaming.jpg</td>
                    <td>
                        <button class="btn btn-solid-warning">Ubah</button>
                        <button class="btn btn-solid-error">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <th>ELC-PLS-1024</th>
                    <td>Mouse Wireless</td>
                    <td>Rp. 150,000</td>
                    <td>150</td>
                    <td>-</td>
                    <td>mousewireless.jpg</td>
                    <td>
                        <button class="btn btn-solid-warning">Ubah</button>
                        <button class="btn btn-solid-error">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <th>HDW-SSD-0307</th>
                    <td>SSD 1TB</td>
                    <td>Rp. 1,200,000</td>
                    <td>80</td>
                    <td>-</td>
                    <td>ssd1tb.jpg</td>
                    <td>
                        <button class="btn btn-solid-warning">Ubah</button>
                        <button class="btn btn-solid-error">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <th>PRT-INK-0425</th>
                    <td>Printer Inkjet</td>
                    <td>Rp. 750,000</td>
                    <td>200</td>
                    <td>-</td>
                    <td>printerinkjet.jpg</td>
                    <td>
                        <button class="btn btn-solid-warning">Ubah</button>
                        <button class="btn btn-solid-error">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <th>HP-HEAD-0199</th>
                    <td>Headset Gaming</td>
                    <td>Rp. 350,000</td>
                    <td>120</td>
                    <td>-</td>
                    <td>headsetgaming.jpg</td>
                    <td>
                        <button class="btn btn-solid-warning">Ubah</button>
                        <button class="btn btn-solid-error">Hapus</button>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>
</div>