<div class="container mx-auto p-4 flex gap-4">

    <div class="card flex">
        <div class="card-body">
            <h2 class="card-header">Total Penjualan Hari ini</h2>
            <!-- <p class="text-content2">Are you looking to increase your productivity at work?</p> -->
            <div class="card-footer">
                <!-- <button class="btn-secondary btn">Learn More</button> -->
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h2 class="card-header">Maximizing Your Productivity at Work</h2>
            <p class="text-content2">Are you looking to increase your productivity at work?</p>
            <div class="card-footer">
                <!-- <button class="btn-secondary btn">Learn More</button> -->
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h2 class="card-header">Maximizing Your Productivity at Work</h2>
            <p class="text-content2">Are you looking to increase your productivity at work?</p>
            <div class="card-footer">
                <!-- <button class="btn-secondary btn">Learn More</button> -->
            </div>
        </div>
    </div>

    <!-- <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div>
    <div class="flex h-40 w-full items-center justify-center border-2 border-dashed border-border bg-gray-1">+</div> -->
</div>