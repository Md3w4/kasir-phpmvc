</div>
</div>
<!-- SIDEBAR: END -->

<script src="<?= BASEURL . '/js/script.js' ?>"></script>
</body>

</html>